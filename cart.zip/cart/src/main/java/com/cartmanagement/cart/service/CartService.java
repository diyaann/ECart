package com.cartmanagement.cart.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartmanagement.cart.model.Cart;
import com.cartmanagement.cart.repo.CartRepository;

@Service
public class CartService {
	
	@Autowired
	CartRepository cartRepository;
	
	@Transactional 
	public List<Cart> getAllItems(){
		return cartRepository.findAll();
	}
	
	@Transactional 
	public void addItem(Cart cart) {
		cartRepository.save(cart);
	}
	
	@Transactional
	public void deleteItem(int productid) {
		cartRepository.deleteById(productid);
	}



}
