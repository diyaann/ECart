package com.cartmanagement.cart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart")

public class Cart {
	@Id
	@Column(name="CartId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartid;
	
	@Column(name="UserId")
	private int userid;
	
	@Column(name="ProductId")
	private int productid;
	
	@Column(name="SellerId")
	private int sellerid;
	
	@Column(name="TotalPrice")
	private int totalprice;
	
	@Column(name="Address")
	private String address;
	
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getSellerid() {
		return sellerid;
	}
	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
