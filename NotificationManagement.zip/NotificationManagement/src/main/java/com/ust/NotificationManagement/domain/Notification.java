package com.ust.NotificationManagement.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Notification")
public class Notification {
	
	@Id
	@Column(name="notificationId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int notificationId;
	@Column(name="notificationTitle")
	private String notificationTitle;
	@Column(name="notificationDescription")
	private String notificationDescription;
	
	public Notification(int notificationId, String notificationTitle, String notificationDescription) {
		super();
		this.notificationId = notificationId;
		this.notificationTitle = notificationTitle;
		this.notificationDescription = notificationDescription;
	}
	
	public int getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}
	public String getNotificationTitle() {
		return notificationTitle;
	}
	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}
	public String getNotificationDescription() {
		return notificationDescription;
	}
	public void setNotificationDescription(String notificationDescription) {
		this.notificationDescription = notificationDescription;
	}
	
	
}
