package com.ust.ProductManagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ProductDetailsTable")
public class ProductDetails {

	@Id
	@Column(name="productId")
	private int productId;
	@Column(name="productName")
	private String productName;
	@Column(name="productSize")
	private int productSize;
	@Column(name="productCategory")
	private String productCategory;
	@Column(name="productPrice")
	private int productPrice;
	@Column(name="sellerId")
	private int sellerId;
	@Column(name="productRating")
	private float productRating;
	
	public ProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductDetails(int productId, String productName, int productSize, String productCategory, int productPrice,
			int sellerId, int productRating) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productSize = productSize;
		this.productCategory = productCategory;
		this.productPrice = productPrice;
		this.sellerId = sellerId;
		this.productRating = productRating;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductSize() {
		return productSize;
	}

	public void setProductSize(int productSize) {
		this.productSize = productSize;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public float getProductRating() {
		return productRating;
	}

	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}
	
	
}
