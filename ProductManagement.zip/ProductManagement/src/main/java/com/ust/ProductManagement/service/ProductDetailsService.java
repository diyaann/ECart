package com.ust.ProductManagement.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.ProductManagement.model.ProductDetails;
import com.ust.ProductManagement.repository.ProductDetailsRepository;

@Service
public class ProductDetailsService {

	@Autowired
	ProductDetailsRepository prodRepo;
	
	@Transactional
	public List<ProductDetails> getAllProducts(){
		return prodRepo.findAll();
	}
	
	@Transactional
	public ProductDetails getProductById(int productId){
		Optional<ProductDetails> prodDet = prodRepo.findById(productId);
		if(prodDet.isPresent()) {
			ProductDetails prodDetail = prodDet.get();
			return prodDetail;
		}
		else
			return null;
	}
	
	@Transactional
	public ProductDetails addProduct(ProductDetails newProduct) {
		return prodRepo.save(newProduct);
	}
	
	@Transactional
	public ProductDetails updateProduct(ProductDetails oldProd) {
		Optional<ProductDetails> oldProduct = prodRepo.findById(oldProd.getProductId());
		if(oldProduct.isPresent())
			return prodRepo.save(oldProd);
		else
			return null;
	}
	
	@Transactional
	public boolean deleteProduct(int productId) {
		Optional<ProductDetails> deleteProduct = prodRepo.findById(productId);
		if(deleteProduct.isPresent()) {
			ProductDetails deleteProd = deleteProduct.get();
			prodRepo.delete(deleteProd);
			return true;
		}
		else
			return false;	
	}
		
}
