package com.ust.ProductManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.ProductManagement.model.ProductDetails;
import com.ust.ProductManagement.service.ProductDetailsService;

@RestController
@RequestMapping("/productDetails")
public class ProductDetailsController {

	@Autowired
	ProductDetailsService prodServ;
	
	@GetMapping("/getAllProducts")
	public ResponseEntity<?> showAllProducts(){
		List<ProductDetails> allProducts = prodServ.getAllProducts();
		return new ResponseEntity<List>(allProducts, HttpStatus.OK);	
	}
	
	@GetMapping("/getProduct/{productId}")
	public ResponseEntity<?> showProductById(@PathVariable int productId){
		ProductDetails product = prodServ.getProductById(productId);
		if(product==null)
			return new ResponseEntity<ProductDetails>(product, HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<ProductDetails>(product, HttpStatus.OK);	
	}
	
	@PostMapping("/addProduct")
	public ResponseEntity<?> addNewProduct(@RequestBody ProductDetails product){
		ProductDetails prod = prodServ.addProduct(product);
		return new ResponseEntity<ProductDetails>(prod, HttpStatus.OK);
	}
	
	@PutMapping("/updateProduct")
	public ResponseEntity<?> updateOldProduct(@RequestBody ProductDetails product){
		ProductDetails prod = prodServ.updateProduct(product);
		return new ResponseEntity<ProductDetails>(prod, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteProduct/{productId}")
	public ResponseEntity<?> deleteAProduct(@PathVariable int productId){
		boolean value = prodServ.deleteProduct(productId);
		if(value)
			return new ResponseEntity<Boolean>(value, HttpStatus.OK);
		else
			return new ResponseEntity<Boolean>(value, HttpStatus.NO_CONTENT);
		}
	}
