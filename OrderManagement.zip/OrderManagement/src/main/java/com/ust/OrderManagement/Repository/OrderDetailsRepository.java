package com.ust.OrderManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.OrderManagement.Model.OrderDetails;

public interface OrderDetailsRepository extends JpaRepository<OrderDetails,Integer> {

}
