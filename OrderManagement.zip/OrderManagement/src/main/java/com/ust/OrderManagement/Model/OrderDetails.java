package com.ust.OrderManagement.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orders")
public class OrderDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="orderId") 
	private int orderId;
	@Column(name="userId") 
	private int userId;
	@Column(name="productId") 
	private int productId;
	@Column(name="sellerId") 
	private int sellerId;
	@Column(name="paymentId") 
	private int paymentId;
	@Column(name="price") 
	private int price;
	@Column(name="address") 
	private String address;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public OrderDetails(int orderId, int userId, int productId, int sellerId, int paymentId, int price,
			String address) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.productId = productId;
		this.sellerId = sellerId;
		this.paymentId = paymentId;
		this.price = price;
		this.address = address;
	}
	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
