package com.ust.OrderManagement.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.OrderManagement.Model.OrderDetails;
import com.ust.OrderManagement.Repository.OrderDetailsRepository;

@RestController
public class OrderDetailsController {
	
	@Autowired
	OrderDetailsRepository orderRepo;
	
	@GetMapping("/order")
	public ResponseEntity<List<OrderDetails>> getAllOrders(){
		List<OrderDetails> od= orderRepo.findAll();
		return new ResponseEntity<>(od,HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping("/order/{id}")
	public ResponseEntity<OrderDetails> getOrderById(@PathVariable("id") int id){
		Optional<OrderDetails> od= orderRepo.findById(id);
		if(od.isPresent()) {
			return new ResponseEntity<OrderDetails>(od.get(),HttpStatus.ACCEPTED);
		}
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	@PostMapping("/order")
	public ResponseEntity<OrderDetails> addOrder(@RequestBody OrderDetails od){
		OrderDetails saveOrder = orderRepo.save(od);
		return new ResponseEntity<OrderDetails>(saveOrder,HttpStatus.ACCEPTED);
	}
	@DeleteMapping("/order/{id}")
	public ResponseEntity<OrderDetails> deleteOrderById(@PathVariable("id") int id){
		Optional<OrderDetails> optionalOrder = orderRepo.findById(id);
		if(optionalOrder.isPresent()) {
			OrderDetails od= optionalOrder.get();
			orderRepo.delete(od);
			return new ResponseEntity<OrderDetails>(od,HttpStatus.ACCEPTED);
		}
		else
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
	}
}
