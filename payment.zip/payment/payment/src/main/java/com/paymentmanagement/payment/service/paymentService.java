package com.paymentmanagement.payment.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paymentmanagement.payment.model.Payment;
import com.paymentmanagement.payment.repository.paymentRepository;

@Service 
public class paymentService {
	
	@Autowired
	paymentRepository paymentRepo;
	
	public void addPayment(Payment payment) {
		paymentRepo.save(payment);
	}
	public Payment getPaymentById(int id) {
		Optional<Payment> optPayment=paymentRepo.findById(id);
		if(optPayment.isPresent()) {
			Payment payment=optPayment.get();
			return payment;
		}
		else 
			return null;
	}
	
}
