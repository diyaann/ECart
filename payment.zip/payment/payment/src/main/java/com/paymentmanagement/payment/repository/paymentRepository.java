package com.paymentmanagement.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paymentmanagement.payment.model.Payment;

public interface paymentRepository extends JpaRepository<Payment, Integer> {

}
