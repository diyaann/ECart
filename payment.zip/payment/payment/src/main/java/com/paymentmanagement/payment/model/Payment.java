package com.paymentmanagement.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="payment")
public class Payment {
	@Id
	@Column(name="paymentId")
	private int id;
	@Column(name="totalPrice")
	private int totalPrice;
	@Column(name="sellerId")
	private int sellerId;
	@Column(name="userId")
	private int userId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(int id, int totalPrice, int sellerId, int userId) {
		super();
		this.id = id;
		this.totalPrice = totalPrice;
		this.sellerId = sellerId;
		this.userId = userId;
	}
	
}
