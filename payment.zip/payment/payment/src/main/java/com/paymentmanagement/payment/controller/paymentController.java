package com.paymentmanagement.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.paymentmanagement.payment.model.Payment;
import com.paymentmanagement.payment.service.paymentService;

@RestController
public class paymentController {
	
	@Autowired
	paymentService paymentservice;
	
	@PostMapping("/payment")
	public ResponseEntity<?> addPayment(@RequestBody Payment payment){
		paymentservice.addPayment(payment);
		return null;
	 }
	@GetMapping("/payment/{id}")
	public ResponseEntity<Payment> getById(@PathVariable int id){
		Payment payment=paymentservice.getPaymentById(id);
		return new ResponseEntity<>(payment,HttpStatus.OK);
	}
	
}
