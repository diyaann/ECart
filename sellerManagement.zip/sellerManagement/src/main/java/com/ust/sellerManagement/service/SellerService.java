package com.ust.sellerManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.sellerManagement.model.Seller;
import com.ust.sellerManagement.repository.SellerRepository;

@Service
public class SellerService {
	@Autowired
	SellerRepository sellerRepo;
	public Seller getSeller(int sellerId) {
		Optional <Seller> sExist = sellerRepo.findById(sellerId);
		if(sExist.isPresent()) {
			return sExist.get();
		}
		else {
			return null;
		}
	}
	public Seller addSeller(Seller sNew) {
		Seller s = sellerRepo.save(sNew);
		return s;
		
	}
	public List<Seller> getAllSeller(){
		return sellerRepo.findAll();
	}
	public Seller updSeller(Seller sellerNew) {
		Optional<Seller> sellerExist = sellerRepo.findById(sellerNew.getSellerId());
		if(sellerExist.isPresent()) {
			Seller sellerOld = sellerExist.get();
			sellerOld.setSellerName(sellerNew.getSellerName());
			sellerOld.setSellerId(sellerNew.getSellerId());
			sellerOld.setSellerReview(sellerNew.getSellerReview());
			sellerOld.setProductId(sellerNew.getProductId());
			return sellerRepo.save(sellerOld);
		}
		else {
			return null;
		}
	}
	public Boolean delSeller(int sellerId) {
		Optional<Seller> sellerExist=sellerRepo.findById(sellerId);
		if(sellerExist.isPresent()) {
			sellerRepo.deleteById(sellerId);
			return true;
		}
		else {
			return false;
		}
	}

}
