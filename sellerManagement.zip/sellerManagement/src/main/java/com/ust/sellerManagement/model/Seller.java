package com.ust.sellerManagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="seller")
public class Seller {
	@Id
	@Column(name="sellerId")
	private int sellerId;
	@Column(name="sellerName")
	private String sellerName;
	@Column(name="productId")
	private int productId;
	@Column(name="sellerReview")
	private String sellerReview;
	
	
	public Seller() {
		super();
	}
	public Seller(int sellerId, String sellerName, int productId, String sellerReview) {
		super();
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.productId = productId;
		this.sellerReview = sellerReview;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getSellerReview() {
		return sellerReview;
	}
	public void setSellerReview(String sellerReview) {
		this.sellerReview = sellerReview;
	}
	

}
