package com.ust.sellerManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SellerManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SellerManagementApplication.class, args);
	}

}
