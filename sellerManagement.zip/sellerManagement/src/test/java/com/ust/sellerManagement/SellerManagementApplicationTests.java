package com.ust.sellerManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellerManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
