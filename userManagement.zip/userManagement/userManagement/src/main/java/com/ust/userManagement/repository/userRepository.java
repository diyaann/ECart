package com.ust.userManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.userManagement.domain.User;

public interface userRepository extends JpaRepository<User, Integer> {
	
	public User findByUserEmailAndUserPassword(String userEmail, String userPassword);

}
