package com.favouritemanagement.favourite.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.favouritemanagement.favourite.model.Favourite;
import com.favouritemanagement.favourite.repo.FavouriteRepository;

@Service
public class FavouriteService {
	@Autowired
	FavouriteRepository favouriteRepository;
	
	@Transactional 
	public List<Favourite> getAllItems(){
		return favouriteRepository.findAll();
	}
	
	@Transactional 
	public void addItem(Favourite favourite) {
		favouriteRepository.save(favourite);
	}
	
	@Transactional
	public void deleteItem(int productid) {
		favouriteRepository.deleteById(productid);
	}

}
