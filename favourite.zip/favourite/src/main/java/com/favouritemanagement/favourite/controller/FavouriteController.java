package com.favouritemanagement.favourite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.favouritemanagement.favourite.model.Favourite;
import com.favouritemanagement.favourite.service.FavouriteService;


@RestController
public class FavouriteController {
	@Autowired 
	FavouriteService favouriteService;
	
	@GetMapping("/getfavs") 
	public List<Favourite> getAllItems() {	
	List<Favourite> carts= favouriteService.getAllItems();
		return carts;			
	}
	
	@PostMapping("/addfav")
	public Favourite createFav(@RequestBody Favourite favourite) {
		favouriteService.addItem(favourite);		
		return favourite;			
	}
	
	@DeleteMapping("/deletefav/{favouriteid}")
	public void deleteFav(@PathVariable int favouriteid) {
		
		favouriteService.deleteItem(favouriteid);
		//return country;			
	}

}
