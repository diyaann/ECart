package com.favouritemanagement.favourite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="favourite")
public class Favourite {
	
	@Id
	@Column(name="FavouriteId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int favouriteid;
	@Column(name="UserId")
	private int userid;
	@Column(name="ProductId")
	private int productid;

	
	public int getUserid() {
		return userid;
	}

	public void setUserid(int iserid) {
		this.userid = iserid;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}
	
	

}
